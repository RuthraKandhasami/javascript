function message() {
    document.write("<h2>Demo</h2>");
    console.log("total args passed:" + arguments.length)
    console.log("value of p1:" + arguments[0]);
    console.log("value of p2:" + arguments[1]);
}// JavaScript source code
