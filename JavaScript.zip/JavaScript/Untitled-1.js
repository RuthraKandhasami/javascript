//var jsonObj={};
var jsonString='{"EmpId":100,"EmpName":"Ruthra"}';
console.log(jsonString);
var jsonObj=JSON.parse(jsonString)
console.log(jsonObj.EmpId);
console.log(jsonObj.EmpName);
var C_Jsonstring=JSON.stringify(jsonObj);
console.log(C_Jsonstring);