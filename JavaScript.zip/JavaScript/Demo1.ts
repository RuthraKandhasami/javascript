class Emp
{
    private empId:number
    private empName:string
    constructor(eId:number,eName:string)
    {
        this.empId=eId;
        this.empName=eName;
    }
    
    public get GetEmpId():number
    {
        return this.empId
    }
        
    public get GetEmpName():string
    {
        return this.empName
    }
    public set SetName(name:string)
    {
        this.empName=name;
    }
    public GetDetails():string
    {
        return "Emp Id:"+this.empId+",Name:"+this.empName
    }
}
let emp1=new Emp(101,'Ruthra K');
console.log("emp id:"+emp1.GetEmpId+",Empname : "+emp1.GetEmpName);
emp1.SetName="Ruthra K";
console.log(emp1.GetDetails());