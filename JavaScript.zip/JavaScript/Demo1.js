var Emp = /** @class */ (function () {
    function Emp(eId, eName) {
        this.empId = eId;
        this.empName = eName;
    }
    Object.defineProperty(Emp.prototype, "GetEmpId", {
        get: function () {
            return this.empId;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Emp.prototype, "GetEmpName", {
        get: function () {
            return this.empName;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Emp.prototype, "SetName", {
        set: function (name) {
            this.empName = name;
        },
        enumerable: true,
        configurable: true
    });
    Emp.prototype.GetDetails = function () {
        return "Emp Id:" + this.empId + ",Name:" + this.empName;
    };
    return Emp;
}());
var emp1 = new Emp(101, 'Ruthra K');
console.log("emp id:" + emp1.GetEmpId);
emp1.SetName = "Ruthra K";
console.log(emp1.GetDetails());
